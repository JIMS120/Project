package kr.co.noorigun.program;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Setter
@Getter
public class RegistryVO {
    private Long num;
    private Long classnum;
    private Long membernum;
}
