package kr.co.noorigun.equipment;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReserveVO {
    private String id;
    private String rname;
    private String remail;
    private int cnt;
}
