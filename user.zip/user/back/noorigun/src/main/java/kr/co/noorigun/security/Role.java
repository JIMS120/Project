package kr.co.noorigun.security;

public enum Role {
    ADMIN,USER
}
