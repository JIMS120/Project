package kr.co.noorigun;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NoorigunApplicationTests {

	@Test
	void contextLoads() {
	}

}
