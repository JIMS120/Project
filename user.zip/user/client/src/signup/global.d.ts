// 다음 API 사용을 위한 설정
declare global {
    interface Window { // Window를 확장해서 새로운 속성 추가
        daum: any;
    }
}
export {};
