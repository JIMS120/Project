package kr.co.noorigun.vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EmailVO {
    private Long num;
    private String name;
    private String email;
    private String id;
}
