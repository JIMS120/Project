package kr.co.noorigun.security;

public enum Role {
    ADMIN,SUPERVISOR,MANAGER,EMPLOYEE
}